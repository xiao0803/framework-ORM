create database EmployeeDB;

create table user(
    name char(5),
    pwd char(3)
);

insert into user values('hehe', '123');
